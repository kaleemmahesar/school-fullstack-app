<?php
// Include the new modular API structure
require_once 'api/index.php';